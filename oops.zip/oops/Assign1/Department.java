package oops.Assign1;

public class Department {
	
	int DeptId;
	String Dname;
	
	Department[] Objects;

}
