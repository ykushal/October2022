package oops.Assign1;

public class Customer  extends Person{

	
	int Date_of_Registration;
	String Delivery_Address;
	int ContantNo;
	String EmailId;
	public int getDate_of_Registration() {
		return Date_of_Registration;
	}
	public void setDate_of_Registration(int date_of_Registration) {
		Date_of_Registration = date_of_Registration;
	}
	public String getDelivery_Address() {
		return Delivery_Address;
	}
	public void setDelivery_Address(String delivery_Address) {
		Delivery_Address = delivery_Address;
	}
	public int getContantNo() {
		return ContantNo;
	}
	public void setContantNo(int contantNo) {
		ContantNo = contantNo;
	}
	public String getEmailId() {
		return EmailId;
	}
	public void setEmailId(String emailId) {
		EmailId = emailId;
	}
	
	
Customer customer = new Customer();

	
	
	
	
}
