package oops.Assign1;

public class Employee extends Department {

	
	
	 int Salary;
	
	 protected Employee() {
		super();
		// TODO Auto-generated constructor stub
	}

	 Employee[] empObjects;
	
	 
	int Date_of_joining;
	String Base_location;
	String Deptobj;
	int ContantNO;
	String EmailId;
	public int getSalary() {
		return Salary;
	}
	public void setSalary(int salary) {
		Salary = salary;
	}
	public int getDate_of_joining() {
		return Date_of_joining;
	}
	public void setDate_of_joining(int date_of_joining) {
		Date_of_joining = date_of_joining;
	}
	public String getBase_location() {
		return Base_location;
	}
	public void setBase_location(String base_location) {
		Base_location = base_location;
	}
	public String getDeptobj() {
		return Deptobj;
	}
	public void setDeptobj(String deptobj) {
		Deptobj = deptobj;
	}
	public int getContantNO() {
		return ContantNO;
	}
	public void setContantNO(int contantNO) {
		ContantNO = contantNO;
	}
	public String getEmailId() {
		return EmailId;
	}
	public void setEmailId(String emailId) {
		EmailId = emailId;
	}
	
	
	Employee employee = new Employee();
	
}
