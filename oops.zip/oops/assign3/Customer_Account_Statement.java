package oops.assign3;

import java.time.LocalDate;

public class Customer_Account_Statement extends Customer {

	

	int CaId;
	int CustId;
	int Amount;
	int Deposit_Withdraw;
	LocalDate Deposit_Date;
	public int getCaId() {
		return CaId;
	}
	public void setCaId(int caId) {
		CaId = caId;
	}
	public int getCustId() {
		return CustId;
	}
	public void setCustId(int custId) {
		CustId = custId;
	}
	public int getAmount() {
		return Amount;
	}
	public void setAmount(int amount) {
		Amount = amount;
	}
	public int getDeposit_Withdraw() {
		return Deposit_Withdraw;
	}
	public void setDeposit_Withdraw(int deposit_Withdraw) {
		Deposit_Withdraw = deposit_Withdraw;
	}
	public LocalDate getDeposit_Date() {
		return Deposit_Date;
	}
	public void setDeposit_Date(LocalDate deposit_Date) {
		Deposit_Date = deposit_Date;
	}

	
	
}
