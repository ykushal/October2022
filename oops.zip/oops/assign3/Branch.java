package oops.assign3;

public class Branch {
	int BranchId;
	String Branch_Name;
	String Branch_Address;
	public int getBranchId() {
		return BranchId;
	}
	public void setBranchId(int branchId) {
		BranchId = branchId;
	}
	public String getBranch_Name() {
		return Branch_Name;
	}
	public void setBranch_Name(String branch_Name) {
		Branch_Name = branch_Name;
	}
	public String getBranch_Address() {
		return Branch_Address;
	}
	public void setBranch_Address(String branch_Address) {
		Branch_Address = branch_Address;
	}
	protected Branch(int branchId, String branch_Name, String branch_Address) {
		super();
		BranchId = branchId;
		Branch_Name = branch_Name;
		Branch_Address = branch_Address;
	}
	@Override
	public String toString() {
		return "Branch [BranchId=" + BranchId + ", Branch_Name=" + Branch_Name + ", Branch_Address=" + Branch_Address
				+ "]";
	}
	

}
