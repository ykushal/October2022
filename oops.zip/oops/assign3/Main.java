package oops.assign3;
 	
public class Main{
	
	
	
	
public static void main(String[] args) {

	
	Branch b = new Branch(0, null, null);
	Customer c = new Customer(0, 0, null, null, null, null, null);
	Customer_Account_Statement ca= new Customer_Account_Statement(0, 0, 0, 0, null);
	
}


}

