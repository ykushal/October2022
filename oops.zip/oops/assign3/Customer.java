package oops.assign3;

import java.time.LocalDate;

public class Customer {
	
	
	int CustId;
	int accountNo;
	String CustomerName;
	String Cust_Address;
	LocalDate Customer_Dob;
	LocalDate Customer_Account_Opening_Date;
	String Branch_obj;
	@Override
	public String toString() {
		return "Customer [CustId=" + CustId + ", accountNo=" + accountNo + ", CustomerName=" + CustomerName
				+ ", Cust_Address=" + Cust_Address + ", Customer_Dob=" + Customer_Dob
				+ ", Customer_Account_Opening_Date=" + Customer_Account_Opening_Date + ", Branch_obj=" + Branch_obj
				+ ", getClass()=" + getClass() + ", hashCode()=" + hashCode() + ", toString()=" + super.toString()
				+ "]";
	}
	public int getCustId() {
		return CustId;
	}
	public void setCustId(int custId) {
		CustId = custId;
	}
	public int getAccountNo() {
		return accountNo;
	}
	public void setAccountNo(int accountNo) {
		this.accountNo = accountNo;
	}
	public String getCustomerName() {
		return CustomerName;
	}
	public void setCustomerName(String customerName) {
		CustomerName = customerName;
	}
	public String getCust_Address() {
		return Cust_Address;
	}
	public void setCust_Address(String cust_Address) {
		Cust_Address = cust_Address;
	}
	public LocalDate getCustomer_Dob() {
		return Customer_Dob;
	}
	public void setCustomer_Dob(LocalDate customer_Dob) {
		Customer_Dob = customer_Dob;
	}
	public LocalDate getCustomer_Account_Opening_Date() {
		return Customer_Account_Opening_Date;
	}
	public void setCustomer_Account_Opening_Date(LocalDate customer_Account_Opening_Date) {
		Customer_Account_Opening_Date = customer_Account_Opening_Date;
	}
	public String getBranch_obj() {
		return Branch_obj;
	}
	public void setBranch_obj(String branch_obj) {
		Branch_obj = branch_obj;
	}
	protected Customer(int custId, int accountNo, String customerName, String cust_Address, LocalDate customer_Dob,
			LocalDate customer_Account_Opening_Date, String branch_obj) {
		super();
		CustId = custId;
		this.accountNo = accountNo;
		CustomerName = customerName;
		Cust_Address = cust_Address;
		Customer_Dob = customer_Dob;
		Customer_Account_Opening_Date = customer_Account_Opening_Date;
		Branch_obj = branch_obj;
	}

	

}
