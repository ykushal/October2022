package oops.assign5;

public class D extends C  {

	@Override
	void div(int a, int b) {
System.out.println(a/b);
super.div(a, b);
	}
	

}
