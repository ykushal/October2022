package oops.assign5;

public abstract class CalcAbs {
	
	void sum(int a, int b) {
	System.out.println(a+b);
	}
	void sub(int a, int b) {
	System.out.println(a-b);
	}

	void mul(int a, int b)
	{
	System.out.println(a*b);	
	}
	
	void div(int a, int b)
	{
		System.out.println(a/b);
	}
}
