package oops.assign8;

public class Laptop  extends Electronics{

	protected Laptop(int id, String semiType, String dateOfManufacturing) {
		super(id, semiType, dateOfManufacturing);
		// TODO Auto-generated constructor stub
	}

}
