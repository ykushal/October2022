package oops.assign8;

public class Mobile extends Electronics {

	protected Mobile(int id, String semiType, String dateOfManufacturing) {
		super(id, semiType, dateOfManufacturing);
		// TODO Auto-generated constructor stub
	}


}
