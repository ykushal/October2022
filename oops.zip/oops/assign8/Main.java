package oops.assign8;

public class Main {
	
	
	public static void main(String[] args) {
		
		Electronics ec = new Electronics(1, "Ic", "2/2/2022");
		Electronics el= new Laptop(2, "battry", "2/2/2020");
		Electronics el1 = new Lcd(3, "chip", "7/1/2012");
		Electronics em = new Mobile(4, "memory", "22/2/1999");
		
		System.out.println(ec);
		System.out.println(el);
		System.out.println(el1);
		System.out.println(em);
	}

}
