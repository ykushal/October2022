package oops.assign8;

public class Lcd  extends Electronics{

	protected Lcd(int id, String semiType, String dateOfManufacturing) {
		super(id, semiType, dateOfManufacturing);
		// TODO Auto-generated constructor stub
	}

}
