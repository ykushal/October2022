package com.java.baisc.string;

public class StringBuilderFasterThanStringBuffer {

	public static void main(String[] args) {
		
		
		
		StringBuilderFasterThanStringBuffer obj = new StringBuilderFasterThanStringBuffer();
		obj.stringBilderDemo();
		obj.stringBufferDemo();
		
	}

	private void stringBufferDemo() {
		
		long startTime = System.currentTimeMillis();
		StringBuffer sbu= new StringBuffer();
		for(long i =1; i<10000000; i++)
		{
			sbu.append(i);
			sbu.append(" ");
			sbu.append(i);
			sbu.append(" ");
			sbu.append(i);
			sbu.append(i);
			sbu.append(" ");
			sbu.append(i);
			sbu.append(" ");
			sbu.append(i);
			
			}
		System.out.println("Time taken String Buffer is: "+((System.currentTimeMillis())-startTime)+ " ");

		
	}

	private void stringBilderDemo() {
		
		long startTime = System.currentTimeMillis();
		StringBuilder sbr= new StringBuilder();
		for(long i =1; i<10000000; i++)
		{
			sbr.append(i);
			sbr.append(" ");
			sbr.append(i);
			sbr.append(" ");
			sbr.append(i);
			sbr.append(i);
			sbr.append(" ");
			sbr.append(i);
			sbr.append(" ");
			sbr.append(i);
			
			}
		System.out.println("Time taken String Builder is: "+((System.currentTimeMillis())-startTime)+ " ");
	}
}
