package com.java.baisc.string;

public class Heap_Scp_Memory_Allocation {
	
	
	public static void main(String[] args) {
		
		String st1= new String("kushal");
		String st2= "kushal";
		String st3 = "kushal";
		if(st1==st2)
		{
			System.out.println("yes");
		}else if(st2==st3)
		{
			System.out.println("Case 2");
		}else
			System.out.println("no");
	}

}
