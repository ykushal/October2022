package com.java.baisc.string;

public class Garbage_Collector {

	
	 public void finalize()
     {
         System.out.println("object is garbage collected");
         }  
     public static void main(String args[]){  
    	 Garbage_Collector s1=new Garbage_Collector();  
    	 Garbage_Collector s2=new Garbage_Collector();  
      s1=null;  
      s2=null;  
      System.gc();  
     }  
}
