package com.java.basic.array;

public class Vowels_Consonants {
	
	
	public static void main(String[] args) {
		
		
		
        int vowels=0, constant=0;
        char cha[]= new char[] {'a','b','c','d','e','f'};
        String str = String.valueOf(cha);
        for(int i=0; i<cha.length; i++)
        {
        if( cha[i] == 'a'|| cha[i] =='e'|| cha[i] =='i' || cha[i]=='o' || cha[i]=='u')
        {
         	
        vowels++;
        
        }else
        {
        	constant++;
        }
        
        }
       
        
        System.out.println("Total vowels are:"+vowels);
        System.out.println("Total consonant :"+constant);
        System.out.println(str);
    
	}

}
