package com.java.basic.array;

public class Duplicate_Number {
public static void main(String[] args) {
	
	
 	int [] arr = new int [] {11, 22, 33, 44, 22, 77, 88, 98, 33};   
 	System.out.println("Duplicate elements in given array: ");  
    //Searches for duplicate element  
    for(int i = 0; i < arr.length; i++) {  
        for(int j = i + 1; j < arr.length; j++) {  
            if(arr[i] == arr[j])  
                System.out.println(arr[j]);  
        }  
    }  
    
}
}
