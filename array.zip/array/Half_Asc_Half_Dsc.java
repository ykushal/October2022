package com.java.basic.array;

import java.util.Arrays;

public class Half_Asc_Half_Dsc {

	
	
	static void printOrder(int[] haf, int n1)

	{
	    Arrays.sort(haf);
	    for (int i = 0; i < n1 / 2; i++)
	        System.out.print(haf[i]+" ");
	 
	    // printing second half in descending
	    // order
	    for (int j = n1 - 1; j >= n1 / 2; j--)
	    System.out.print(haf[j]+" ");
	     
	}
	
	
	public static void main(String[] args) {
        int[] haf = { 85, 42, 64, 92, 11, 63, 98, 29, 37 };
        int n1 = haf.length;
        printOrder(haf, n1);
	
	}
}
