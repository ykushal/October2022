package com.java.basic.array;

import java.util.Scanner;

public class Dynamic_Array {

	
	
	public static void main(String[] args) {
		
		
        //------------------- Dynamic array------------------------
        Scanner sc = new Scanner(System.in);
        System.out.println("Enter Size of array");
        int size= sc.nextInt();
        int dynaicarr[]= new int[size];
        System.out.println("Enter Elelment of array");
        for(int i=0; i<dynaicarr.length; i++)
        {
        	dynaicarr[i]= sc.nextInt();
        }
        System.out.println("array size is: "+size);
        for(int i=0; i<dynaicarr.length; i++)
        {
        	System.out.println(dynaicarr[i]);
        }
	}
}
