package com.java.basic.array;

public class Maxinum_Number_Array_List {
	public static void main(String[] args) {
		
		
		int b[]= {10,2,3,41,12,13,19,81,9};
		// Arrays.sort(b); 
		 int tem;
		 for(int i =0; i<b.length; i++)
		 {
			for(int j=i+1; j<b.length;j++)
			{
				if(b[i]>b[j]) {
					tem=b[i];
					b[i]=b[j];
					b[j]=tem;
				}
			}
		 }
		System.out.println("Sorted List:");
		for(int x:b)
		{
			System.out.println(x);
		}
		 System.out.println("maximun length: " +b[b.length-3]);
	}

}
