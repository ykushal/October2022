package com.java.basic.array;

public class Basic_Array {
public static void main(String[] args) {
	
	 int a[]; //decleration
	 a= new  int [3]; //creation
	 a[0]=10;// initialization
	 a[1]=20;
	 a[2]=30;
	 System.out.println(a);
	 System.out.println(a[1]);
	 
	 //traversing of array
	 for(int i =0; i<a.length; i++)
	 {
		 System.out.println(a[i]);
		 
	 }
}
}
