package com.java.basic.array;

public class Even_Odd_Prime_Perfect {
	
	static void CountingEvenOdd(int ar[], int ar_size)
    {
        int even_count = 0;
        int odd_count = 0;
        for (int i = 0; i < ar_size; i++) {
            if ((ar[i] & 1) == 1)
                odd_count++;
            else
                even_count++;
        }
        System.out.println("Number of even" +" elements = " + even_count + " Number of odd elements = "+ odd_count);
    }
	
	
	
	public static void main(String[] args) {
		
		  int ar[] = { 2, 3, 4, 5, 6,8,10,12 };
	        int n = ar.length;
	        CountingEvenOdd(ar, n);
	}

}
